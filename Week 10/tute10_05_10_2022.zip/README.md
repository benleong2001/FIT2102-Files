# Week 10 Worksheet

see [worksheet](./worksheetChecklist.html) and [notes](https://tgdwyer.github.io/monad/)