module Main where

main :: IO ()
main = print "Hello World!"
